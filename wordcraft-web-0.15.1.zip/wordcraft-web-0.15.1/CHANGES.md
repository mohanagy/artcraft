# Embedded web profile — rounds 1–3

Local branch `embed/profile`, based on `08afab50`. No pushes. Application version 0.15.1; host protocol remains **1**.

The normal feature-off application keeps its existing behavior. Embedded-specific UI, host and resource changes are gated to wasm32; selecting the feature on native does not activate the embedded interface. `embedded-lite` is a separate opt-in resource variant and implies `embedded`. No font binaries were added to either app repository. Package licence/notice files are retained; generic fixtures are attributed.


## Round 3: host surfaces and available tools

Protocol remains **1**. The two additional `configure.chrome` booleans are `fileNew` and `fileClose`; both default to **true**. Sending false removes the File entry and blocks its associated command/shortcut and command-search paths. These values merge and can be restored with true, just like the previous switches.

```js
{type:"wordcraft:configure", chrome:{fileNew:false,fileClose:false},
 theme:{dialog:"#ffb2ed",popup:"#b7ffce",toast:"#ffcc85",tooltip:"#e7c7ff",
        toolstrip:"#95f4f0",scrollbar:"#ffbc7d",scrollbarThumb:"#6c138c",
        backstageNav:"#79edaa",backstageContent:"#fcdf95"}}
```

The color grammar and validation are unchanged: #RGB, #RRGGBB or #RRGGBBAA, including alpha; camelCase and snake_case token names are accepted. Unknown keys and invalid values appear in `configured.ignored` and retain the previous value. No CSS, JavaScript or URL color values are accepted. New slots inherit already configured legacy slots if omitted, and independent region overrides win. Host colors apply only on the embedded wasm target. Theme/appearance controls are removed from that UI so the host remains the authority.

### Region → host slot

| Region | Slot(s) |
|---|---|
| Title bar / tab strip | `titleBar / tabStrip` |
| Main ribbon / floating formatting strip | `toolstrip; ribbon remains its legacy fallback` |
| Side panels | `panel, text, textDim, icon` |
| Dialog bodies and title frames | `dialog` |
| Stock menu and popup frames | `popup; explicitly painted menu regions also use menu` |
| File navigation / File content | `backstageNav / backstageContent` |
| Transient status notice / normal status bar | `toast / statusBar` |
| Not saved acknowledgement notice | `dialog` |
| Pointer, keyboard-focus and disabled tooltips | `tooltip` |
| Scroll area tracks / thumbs, including document canvas | `scrollbar / scrollbarThumb` |
| Fields, hover, pressed, borders | `input, inputBorder, hover, pressed, border, borderStrong` |
| Text, disabled text, icons, group labels | `text, textDim, textDisabled, icon, groupLabel, onAccent` |
| Ruler / canvas / UI selection overlays | `ruler, rulerMargin, rulerTick, canvas, selection, handle, guide, cropHandle and existing overlay tokens` |
| Shadows / modal backdrop | `pageShadow; handleShadow for object handles` |
| Comment balloons and author leaders | `balloon, markupArea, markupEdge, authorColors, leaderColors` |
| Semantic accents / close controls | `blue, red, green, orange, closeHover, closePressed, onClose` |

Hover/pressed blends, outlines, shadows, stock widget fills and IME underlines use host tokens. Scroll-area styling is scoped: the scrollbar gets its own track/thumb palette while the area contents retain their original host widget palette. Dropdowns supplied by shared widgets inherit host foreground/field colors. Transparent layout frames, texture tint identity colors and measurement-only colors are not independent visible surfaces.

Document paper, actual document text/graphics, imported images, swatches, document style/chart previews, print thumbnails and signature previews retain document colors. No font or other asset binary was added. Licensing and attribution text stays intact.

### Removed or hidden in this round

- The non-working Researcher command (`references.researcher`), its ribbon group and keytip, including command-search/custom-toolbar dispatch.
- The Agents options pane and its AI/MCP descriptive text. No online model/provider implementation was present at this pin.
- The interface theme picker in Options and View, and the interface-theme command/search paths (`view.interfaceTheme`, `ui.theme`, `ui.darkMode`). Document Switch Modes is a document display control and remains separate.
- The account-labelled avatar in the title bar. Local document author/initials remain document metadata, not an online account.
- On host request: File New/template gallery and Close; `file.new*` and `file.close*` paths are blocked. Hidden controls are also filtered from QAT and command search. If the active File page becomes hidden, the app selects a visible page rather than leaving an empty page.
- Network/update/download/community controls removed in round 1 remain excluded. This round does not introduce network or provider settings.

### Round 3 verification and release evidence

Workspace embedded-feature unit tests: **4,163 passed, 0 failed, 4 ignored**. Strict all-targets embedded-feature Clippy, formatting, layering, asset and embedded WASM checks passed. All nine `cargo xtask ci` stages passed.

Both release builds completed with Binaryen `-Oz`. Exact byte accounting follows; categories sum to each file size. Resources are exact source matches in reconstructed WASM memory; `other` includes unmatched/transformed data and runtime/section overhead. These categories are not independent removable/compressed-download estimates.

| Variant | Total bytes | Code | Fonts | Dictionaries | Locale data | Other |
|---|---:|---:|---:|---:|---:|---:|
| web | 56,540,755 | 36,303,226 | 8,221,529 | 3,293,106 | 5,339,450 | 3,383,444 |
| web-lite | 54,824,743 | 36,307,963 | 8,058,865 | 3,293,106 | 3,782,302 | 3,382,507 |

Full WASM changed from round 2's **56,750,010** to **56,540,755** bytes (-209,255); optional lite saves **1,716,012** bytes relative to this full build. Each file hash and resource attribution is in `embedded-test/size-web.json` / `size-web-lite.json`.

Case-insensitive raw scans cover every final `.wasm` and `.js` in both outputs. Every hit has an offset, context and reason in `embedded-test/artifact-search.json` and `artifact-search-lite.json`; **zero unclassified hits**. Counts include non-actionable data:

| Needle | Full hits | Lite hits |
|---|---:|---:|
| `discord` | 8 | 8 |
| `getartcraft` | 0 | 0 |
| `storytold` | 0 | 0 |
| `github.com` | 9 | 9 |
| `http://` | 346 | 346 |
| `https://` | 32 | 32 |
| `milestone` | 5 | 5 |
| `bring your own` | 0 | 0 |
| `provider` | 22 | 22 |

The eight `discord` hits are ordinary discordance/discordant proofing words; `milestone` is four regional dictionary entries plus a working Flag icon search keyword. Provider matches are local font/ICU/Office encryption metadata, proofing words and Brotli data. URL/hostname matches are document/XML/SVG format identifiers, licences/provenance, dependency diagnostics, parser tokens and Brotli dictionary bytes; the per-hit reports distinguish each source.

The final full artifact passed all **11** harness result flags, including 58 loud theme settings accepted, ready/version/protocol, branding, rename, clean/dirty requestSave, positive/negative acknowledgements, timeout, blank clean open and Save As. Observed UI regions and removals are listed in `embedded-test/browser-results.json`. Shared unit coverage and visited screens support the surface changes; every possible dialog/hover state was not manually enumerated. Cross-browser and exhaustive document-fidelity acceptance remain unverified. Lite was built, measured and string-audited; this browser run used full embedded.


The local test page includes `loud-theme.json` and sends a distinct loud color for every accepted color setting. Its manual checklist covers UI regions, hidden New/Close and their shortcuts, absent placeholder/AI search results, and removed Preferences sections. Protocol, branding, open/dirty/save/ack/timeout checks from round 2 remain available. Only generic fixtures are used.

## Build and deliverables

Use Rust installed through rustup, the wasm32-unknown-unknown target, Trunk and wasm-bindgen 0.2.129 (matching Cargo.lock). The toolchain used here is Rust 1.99.1, Trunk 0.22.1 and Binaryen 133. The HTML requests wasm-opt `z` (`-Oz`).

```sh
# From apps/wordcraft-web; use absolute paths for these build inputs.
export CRAFT_I18N_DIR=/absolute/path/to/the-checkout-pinned-in-craft-i18n.rev
export CRAFT_I18N_REQUIRED=1
export CRAFT_FONTS_DIR=/absolute/path/to/licensed-craft-fonts
trunk build --skip-version-check --release --locked --features embedded \
  --html-output index.html index-embedded.html
# Optional, separate output; keeps dist/web as the full embedded build.
trunk build --skip-version-check --release --locked --features embedded-lite \
  --dist ../../dist/web-lite --html-output index.html index-embedded.html
```

`packaging/web/build-embedded.sh` builds/packages the full embedded site. Default `index.html` and normal Trunk commands still build the standard app; the explicit `index-embedded.html` is necessary to white-label the pre-WASM loading/title. Fonts input is pinned at `b076417b5880bd4154bd22f00695b1d28c6bea83`; translation pin is the repository's `craft-i18n.rev`. Full builds retain the previous round's font/data inputs.

Full site: `dist/web`. Optional measured variant: `dist/web-lite`. Full release ZIP retains the previous name/layout, `dist/embedded-release/wordcraft-web-0.15.1.zip`. Serve the whole extracted folder with WASM/JavaScript MIME types; relative assets support subpaths. `embedded-test/index.html` in the ZIP points to the app root. In the source checkout it points to `../dist/web/`. Serve only generated files and generic fixtures, on loopback for local checks.

## Host protocol and validation

Use a **same-origin** iframe with `?host=parent`. Incoming messages must come from the exact parent window and origin; replies target that origin, never `*`. Existing ready/open/dirty/save messages remain. The protocol's app prefix is unchanged even though visible branding is neutral.

```js
// App -> host
{type:"wordcraft:ready", version:"0.15.1", protocol:1}
// Host -> app; valid fields merge live, omitted fields retain their values
{type:"wordcraft:configure",
  colorScheme:"light", // light | dark | system
  locale:"en", // available exact locale, including ar
  branding:{name:"Sample Editor"}, // optional, 1..40 Unicode characters
  ackSave:true, // optional; default false
  theme:{accent:"#146c43", accentText:"#ffffff", accentSoft:"#dbf2e4"},
  chrome:{titlebar:false, homeTab:false, openTab:false}}
// App -> host; dotted paths; invalid/unknown values do not reset prior values
{type:"wordcraft:configured", applied:["branding.name","ackSave"], ignored:["unknown"]}
// Host -> app; existing bytes contract
{type:"wordcraft:open", name:"sample.docx", bytes:ArrayBuffer /* or Uint8Array */}
{type:"wordcraft:rename", name:"Renamed.docx"}
{type:"wordcraft:requestSave"}
{type:"wordcraft:saved", ok:true}
{type:"wordcraft:saved", ok:false, error:"Generic storage failure"}
// App -> host; existing bytes contract, including Save As from the editor
{type:"wordcraft:dirty", dirty:true}
{type:"wordcraft:save", name:"Renamed.docx", saveAs:false, bytes:ArrayBuffer}
```

Configuration/rename/ack payloads are bounded to 64 KiB. Configuration objects are capped at 128 keys. Unknown keys are ignored. Booleans must be actual booleans. Colour strings accept only `#RGB`, `#RRGGBB`, `#RRGGBBAA`; colour arrays require exactly five valid colours. Known snake_case tokens and camelCase aliases work. Computed palette selectors cannot be overridden. Available colour tokens: `titleBar`, `ribbon`, `tabStrip`, `canvas`, `panel`, `border`, `borderStrong`, `text`, `textDim`, `textDisabled`, `icon`, `hover`, `pressed`, `checked`, `accent`, `nav`, `accentText`, `onAccent`, `input`, `inputBorder`, `groupLabel`, `ruler`, `rulerMargin`, `rulerTick`, `statusBar`, `selection`, `findHighlight`, `pageShadow`, `handle`, `handleShadow`, `guide`, `equationBox`, `cropHandle`, `cropDim`, `balloon`, `markupArea`, `markupEdge`, `resolvedText`, `authorColors`, `leaderColors`, `menu`, `blue`, `red`, `green`, `orange`, `closeHover`, `closePressed`, `onClose`.
`accentSoft` is an alias for WordCraft's existing `checked` token.

`branding.name` rejects empty/whitespace-only strings, controls, and more than 40 Unicode characters. It changes UI application-name labels, About content, welcome text and document/browser titles live. Before configuration the visible name is **Editor**. Application logos and branded credits are omitted in embedded wasm; package legal notices remain. Host names are rendered as text; they are never interpreted as HTML. Document content and supplied filenames are not rewritten as branding.

`rename` accepts 1..200 Unicode characters, rejects controls and both path separators (also blank-only and dot/dot-dot names), and changes the displayed name/window title and suggested save filename without marking document content dirty. There is no new rename response message. Invalid names are ignored.

`requestSave` directly invokes saving and emits the existing save payload with `saveAs:false`, even for a clean document and while keyboard focus is in the host. It does not rely on synthetic key events. Existing user Save As still emits `saveAs:true`.

With `ackSave:false`/omitted, saves retain their prior behavior. With `ackSave:true`, a delivered save remains unsaved until `saved {ok:true}`. Failed acknowledgements and a 30-second missing acknowledgement retain dirty state and show a dismissible **Not saved** notice. Host error text is sanitized and capped at 200 Unicode characters. Pending saves request periodic repaint checks, so an idle editor still displays the timeout. Acknowledgements clear only the stored document revision; edits made after that snapshot remain dirty.

Protocol 1 has no request IDs. Saves are serialized while an acknowledgement is pending. A timed-out acknowledgement is treated conservatively: one subsequent acknowledgement is consumed as stale instead of being allowed to confirm a newer save. Hosts should acknowledge every outgoing save in order, including failures. If an acknowledgement was permanently lost, reload/reopen after retaining the host's bytes to reset ambiguous acknowledgement state. No claim of arbitrary overlapping/out-of-order save correlation is made.

## Chrome switches

Supported booleans: `fileNew`, `fileClose`, `titlebar`, `homeTab`, `openTab`, `autosave`, `share`, `quickAccessToolbar`, `citationsTab`, `comments`, `editingMode`. Unspecified controls stay visible. Hidden controls free their layout space. Disabled dedicated navigation/actions are filtered before dispatch; host-supplied bytes still open when the picker is hidden.

Exactly what `titlebar:false` hides: **The entire 38px title bar: AutoSave and its toggle, Quick Access Toolbar (including its Save/Undo/Redo buttons), centred document name/rename control, Search, and window-drag area (the account avatar is already compiled out in round 3). The ribbon tabs, ribbon tools, canvas, status bar, and document keyboard shortcuts remain. `quickAccessToolbar:false` can instead hide only that toolbar. `comments:false` hides the top-right Comments button and its `view.commentsPane` action; Insert/Review comment editing remains. `editingMode:false` hides the Editing/Reviewing mode dropdown; Review-tab tools remain. `citationsTab:false` hides the Zotero reference-manager tab and its actions; the built-in References tab remains.**

Undo, redo, Save and Find remain keyboard commands when titlebar is hidden. Word's existing Find-field focus rules still apply to document shortcuts; host `requestSave` works from any focus. Use File → Save As; the pinned web keymap uses Cmd+Shift+S for Styles.

## Opening and dirty state

A completed host open establishes the imported/canonicalized document as the clean baseline. Load-time normalization is retained as baseline data, not reported as a user edit. Initial clean opens emit `dirty:false`, including clean-to-clean switches. Invalid opens/password prompts must not clear an existing document's edits. Subsequent real edits report dirty normally.

The generic blank fixtures and blank-document unit tests do not reproduce the original host's exact bytes; the precise normalization/style upgrade in that original document therefore remains unknown. The implementation explicitly accepts the successfully loaded baseline rather than guessing an Office-style rule. Regression tests cover blank opening and revision-aware acknowledgements.

## Embedded removals retained from round 1

Discord UI, Help/Backstage/keytip entries and handlers; promotional catalog rows; product/community/repository/contributor hyperlinks; update checks; language/model/data downloads; external document-link navigation. No empty control placeholders are left. Local open/save/export/printing remain. The sample document product hyperlink and LaTeX product-URL comment are also compiled out. The web app does not link MCP.

## Fonts and the optional lite variant

The synthetic Word test document requests **Aptos, Calibri and Cambria** by family name and embeds
no font programs. These proprietary Office families are absent from the bundled font set. Other Office
fonts, such as Arial, Times New Roman and Courier New, likewise require an available licensed face
or substitution. A document's own embedded/licensed fonts and fonts explicitly imported by the user
can change availability; naming a font in a document does not grant redistribution rights.

Suggested licensed fallbacks: **Source Sans 3** for Aptos/Calibri/Arial and **Source Serif 4** for
Cambria/Times New Roman (OFL-1.1, already bundled by WordCraft); **JetBrains Mono** for Courier New
(OFL-1.1). They are not guaranteed metric-compatible with every Office face. Carlito/Caladea and
Liberation are existing resolver candidates when available; none were downloaded or added here.
PDFs with embedded font programs retain them. Missing unembedded PDF font families need per-document
inspection; the generic PDF fixture uses a standard-14 Helvetica reference, with no proprietary font file.

The full embedded build does not drop fonts or language resources in round 2. The optional `embedded-lite` feature removes selected non-Latin/Arabic/Hebrew shared faces and selected locale catalogs: `zh-hans`, `zh-hant`, `ja`, `ko`, `uk`, `ru`, `bg`, `sr`, `th`, `hi`, `te`, `ka` (where present). Latin-script resources and Arabic remain. A Hebrew face from the same licensed shared font checkout is retained explicitly by the lite Word build; the original Word web build did not embed that shared Hebrew face. It is off by default. This is a resource experiment, not an assertion that every other script is gone. The pinned proofing crate has small unconditional supplements (including Russian) that remain; renderer/runtime Unicode tables remain as well.

## Files touched against the pinned base

- `ATTRIBUTION.md`
- `CHANGES.md`
- `apps/wordcraft-web/Cargo.toml`
- `apps/wordcraft-web/index-embedded.html`
- `apps/wordcraft-web/src/host.rs`
- `apps/wordcraft-web/src/web.rs`
- `crates/engine/Cargo.toml`
- `crates/engine/src/cmd/citations.rs`
- `crates/engine/src/cmd/view.rs`
- `crates/engine/src/sample.rs`
- `crates/fonts/Cargo.toml`
- `crates/fonts/build.rs`
- `crates/formats/Cargo.toml`
- `crates/formats/src/latex/export.rs`
- `crates/mcp/Cargo.toml`
- `crates/mcp/src/server.rs`
- `crates/ui-egui/Cargo.toml`
- `crates/ui-egui/build.rs`
- `crates/ui-egui/src/a11y_pane.rs`
- `crates/ui-egui/src/app.rs`
- `crates/ui-egui/src/app/commands.rs`
- `crates/ui-egui/src/app/files.rs`
- `crates/ui-egui/src/app/frame.rs`
- `crates/ui-egui/src/backstage.rs`
- `crates/ui-egui/src/canvas.rs`
- `crates/ui-egui/src/canvas/input.rs`
- `crates/ui-egui/src/canvas/margins.rs`
- `crates/ui-egui/src/chrome.rs`
- `crates/ui-egui/src/colors.rs`
- `crates/ui-egui/src/content_controls.rs`
- `crates/ui-egui/src/credits.rs`
- `crates/ui-egui/src/dialogs/bookmarks.rs`
- `crates/ui-egui/src/dialogs/chrome.rs`
- `crates/ui-egui/src/dialogs/dialogs_chart.rs`
- `crates/ui-egui/src/dialogs/dialogs_insert/columns.rs`
- `crates/ui-egui/src/dialogs/dialogs_insert/field.rs`
- `crates/ui-egui/src/dialogs/dialogs_insert/symbol.rs`
- `crates/ui-egui/src/dialogs/dialogs_keyboard.rs`
- `crates/ui-egui/src/dialogs/dialogs_layout/text.rs`
- `crates/ui-egui/src/dialogs/dialogs_para.rs`
- `crates/ui-egui/src/dialogs/dialogs_refs/cross_ref.rs`
- `crates/ui-egui/src/dialogs/dialogs_refs/sources.rs`
- `crates/ui-egui/src/dialogs/dialogs_refs/toc.rs`
- `crates/ui-egui/src/dialogs/dialogs_review.rs`
- `crates/ui-egui/src/dialogs/dialogs_ribbon.rs`
- `crates/ui-egui/src/dialogs/dialogs_smart_art.rs`
- `crates/ui-egui/src/dialogs/dialogs_table_style.rs`
- `crates/ui-egui/src/dialogs/dialogs_templates.rs`
- `crates/ui-egui/src/dialogs/dispatch.rs`
- `crates/ui-egui/src/dialogs/forms.rs`
- `crates/ui-egui/src/dialogs/mailings.rs`
- `crates/ui-egui/src/dialogs/styles.rs`
- `crates/ui-egui/src/embedded.rs`
- `crates/ui-egui/src/equation_tab.rs`
- `crates/ui-egui/src/file_browser.rs`
- `crates/ui-egui/src/file_dialogs.rs`
- `crates/ui-egui/src/format_shape.rs`
- `crates/ui-egui/src/host_state.rs`
- `crates/ui-egui/src/icons.rs`
- `crates/ui-egui/src/keytips.rs`
- `crates/ui-egui/src/language_packs.rs`
- `crates/ui-egui/src/lib.rs`
- `crates/ui-egui/src/mini_toolbar.rs`
- `crates/ui-egui/src/objects.rs`
- `crates/ui-egui/src/options.rs`
- `crates/ui-egui/src/panes.rs`
- `crates/ui-egui/src/panes/comments.rs`
- `crates/ui-egui/src/panes/inspector.rs`
- `crates/ui-egui/src/panes/nav.rs`
- `crates/ui-egui/src/panes/side.rs`
- `crates/ui-egui/src/previews.rs`
- `crates/ui-egui/src/print_page.rs`
- `crates/ui-egui/src/proofing_pane.rs`
- `crates/ui-egui/src/read_aloud.rs`
- `crates/ui-egui/src/ribbon.rs`
- `crates/ui-egui/src/ribbon/charts.rs`
- `crates/ui-egui/src/ribbon/common.rs`
- `crates/ui-egui/src/ribbon/draw.rs`
- `crates/ui-egui/src/ribbon/insert.rs`
- `crates/ui-egui/src/ribbon/mailings.rs`
- `crates/ui-egui/src/ribbon/picture.rs`
- `crates/ui-egui/src/ribbon/references.rs`
- `crates/ui-egui/src/ribbon/review.rs`
- `crates/ui-egui/src/ribbon/table.rs`
- `crates/ui-egui/src/ribbon/underline.rs`
- `crates/ui-egui/src/ribbon/view.rs`
- `crates/ui-egui/src/ruler_tabs.rs`
- `crates/ui-egui/src/scroll.rs`
- `crates/ui-egui/src/table_mouse.rs`
- `crates/ui-egui/src/table_resize.rs`
- `crates/ui-egui/src/table_ruler.rs`
- `crates/ui-egui/src/theme.rs`
- `crates/ui-egui/src/updates_ui.rs`
- `crates/ui-egui/src/widgets/buttons.rs`
- `crates/ui-egui/src/widgets/combo.rs`
- `crates/ui-egui/src/widgets/groups.rs`
- `crates/ui-egui/src/widgets/icon_buttons.rs`
- `crates/ui-egui/src/widgets/tooltip.rs`
- `crates/ui-egui/src/window_close.rs`
- `crates/ui-egui/src/window_ui.rs`
- `crates/ui-egui/src/windows.rs`
- `crates/ui-egui/src/wordart_menus.rs`
- `crates/ui-egui/src/zotero.rs`
- `embedded-test/artifact-search-lite.json`
- `embedded-test/artifact-search.json`
- `embedded-test/blank.docx`
- `embedded-test/browser-results.json`
- `embedded-test/index.html`
- `embedded-test/loud-theme.json`
- `embedded-test/sample.docx`
- `embedded-test/size-web-lite.json`
- `embedded-test/size-web.json`
- `embedded-test/verification.json`
- `packaging/web/build-embedded.sh`
