# Embedded web build changes

Local branch: `embed/profile`, based on `08afab50` (not main). Nothing was pushed.
The `embedded` Cargo feature is opt-in and applies its behavior changes only on wasm32.
Native builds, including native builds with the feature selected, preserve their existing behavior.

## Build and host

From `apps/wordcraft-web`:

```sh
CRAFT_I18N_DIR=/absolute/path/to/pinned-craft-i18n CRAFT_I18N_REQUIRED=1 \
CRAFT_FONTS_DIR=/absolute/path/to/licensed-craft-fonts \
trunk build --skip-version-check --release --locked --features embedded
```

The translation checkout must match `craft-i18n.rev`. The font checkout used here is
`b076417b5880bd4154bd22f00695b1d28c6bea83`. Fonts and proofing data are the same for the
baseline and embedded size comparison. No new font files were added to either app repository.
`bash packaging/web/build-embedded.sh` builds and packages the embedded site with those environment variables.
The normal `trunk build --release` and existing packaging script continue to build the normal application.
The generated site is `dist/web`; serve the whole folder over HTTPS (localhost HTTP is sufficient for development),
with `application/wasm` for `.wasm` and JavaScript module MIME types for `.js`. Relative asset URLs support subpaths.

## Host protocol (version 1)

Use a same-origin iframe with `?host=parent`. Both the sender's origin and its window identity
must match the actual parent. Replies use that origin, never `*`. Config messages are available
only in the embedded build; existing open/save/dirty behavior remains available as before.

```js
// App -> parent, after listener registration / runner startup
{ type: "wordcraft:ready", version: "0.15.1", protocol: 1 }
// Parent -> app
{ type: "wordcraft:configure",
  colorScheme: "light", // "dark" or "system"
  locale: "en", // an available exact locale code, e.g. "ar"
  theme: { accent: "#146c43", accentText: "#075e21", accentSoft: "#dbf2e4" },
  chrome: { titlebar: true, homeTab: true, openTab: true } }
// App -> parent
{ type: "wordcraft:configured", applied: ["colorScheme", "locale", "theme.accent"], ignored: ["unknown"] }
// Parent -> app: existing file-open message
{ type: "wordcraft:open", name: "sample.docx", bytes: ArrayBuffer /* or Uint8Array */ }
// Existing app -> parent messages
{ type: "wordcraft:dirty", dirty: true }
{ type: "wordcraft:save", name: "sample.docx", saveAs: false, bytes: ArrayBuffer }
```

Configuration merges with previous valid values, takes effect on the next app frame, and requests
a repaint. Replies acknowledge accepted fields. Unknown or invalid fields are ignored individually
and reported by dotted path, without resetting prior values. Messages larger than 64 KiB and objects
with more than 128 keys are rejected. Colours accept only `#RGB`, `#RRGGBB`, or `#RRGGBBAA`;
colour arrays require exactly five valid colours. Computed palette selectors (`dark`/`kind`) cannot
be overridden. Canonical snake_case token names and camelCase equivalents are both accepted.

Available colour tokens: `titleBar`, `ribbon`, `tabStrip`, `canvas`, `panel`, `border`, `borderStrong`, `text`, `textDim`, `textDisabled`, `icon`, `hover`, `pressed`, `checked`, `accent`, `nav`, `accentText`, `onAccent`, `input`, `inputBorder`, `groupLabel`, `ruler`, `rulerMargin`, `rulerTick`, `statusBar`, `selection`, `findHighlight`, `pageShadow`, `handle`, `handleShadow`, `guide`, `equationBox`, `cropHandle`, `cropDim`, `balloon`, `markupArea`, `markupEdge`, `resolvedText`, `authorColors`, `leaderColors`, `menu`, `blue`, `red`, `green`, `orange`, `closeHover`, `closePressed`, `onClose`.
`accentSoft` is an alias for WordCraft's existing `checked` token.

Supported chrome booleans: `titlebar`, `homeTab`, `openTab`, `autosave`, `share`, `quickAccessToolbar`. Unspecified controls stay visible.
Hidden controls do not allocate their layout space. Open/Home navigation and AutoSave/Share actions
(where present) are checked before UI command and shortcut dispatch. Host-supplied file bytes still
open when the Open picker is hidden. Hiding a container does not disable unrelated document editing
or saving operations that also appear elsewhere in the interface. Restore a control by sending `true`.

## Removed from embedded web

Discord buttons, Help/Backstage entries, keytips, action handlers and promotional catalog rows;
community, product, repository and contributor-profile hyperlinks; update-check actions; language-pack
installer UI/background work; and external document-link navigation. Local document open/save/export
and printing remain available. The generated application has no automatic model/data download added.
WordCraft's built-in sample product hyperlink and LaTeX product-URL comment are compiled out. The MCP crate is not linked into the web app; its optional embedded wasm feature also omits community instructions.

## Fonts

The synthetic Word test document requests **Aptos, Calibri and Cambria** by family name and embeds
no font programs. These proprietary Office families are absent from the bundled font set. Other Office
fonts, such as Arial, Times New Roman and Courier New, likewise require an available licensed face
or substitution. A document's own embedded/licensed fonts and fonts explicitly imported by the user
can change availability; naming a font in a document does not grant redistribution rights.

Suggested licensed fallbacks: **Source Sans 3** for Aptos/Calibri/Arial and **Source Serif 4** for
Cambria/Times New Roman (OFL-1.1, already bundled by WordCraft); **JetBrains Mono** for Courier New
(OFL-1.1). They are not guaranteed metric-compatible with every Office face. Carlito/Caladea and
Liberation are existing resolver candidates when available; none were downloaded or added here.
PDFs with embedded font programs retain them. Missing unembedded PDF font families need per-document
inspection; the generic PDF fixture uses a standard-14 Helvetica reference, with no proprietary font file.

## Verification

- Existing workspace unit tests: `cargo test --workspace --lib --bins --features wordcraft-ui-egui/embedded -- --test-threads=4`: **4154 passed, 0 failed, 4 ignored**. Ignored tests remain explicitly unverified.
- New parser and hidden-action policy regression tests: **PASS** (included above).
- `cargo xtask layers`: **PASS**. `cargo xtask assets`: **PASS**. Rust formatting and `git diff --check`: **PASS**.
- Default/no-embedded WebAssembly compile check: `cargo check -p wordcraft-web --target wasm32-unknown-unknown --locked`: **PASS**.
- Release WebAssembly build with Trunk and Binaryen `wasm-opt -Oz`: **PASS**.
- Browser on localhost, same-origin `?host=parent` iframe: ready with version/protocol, valid configure with unknown-field rejection, generic sample visibly opened, dirty true/false, Save with `saveAs:false`, and Save As with `saveAs:true`: **PASS**. Light/dark, Arabic and chrome hide/restore were observed live.
- Browser result stamp: [browser-results.json](embedded-test/browser-results.json). The test page distinguishes `openSent` from visual confirmation of the sample. File signatures were checked; this was a bridge smoke test, not an exhaustive document-fidelity test.

### Optimized WASM size

Both builds use the same pinned fonts/data and `-Oz`. Runtime configuration adds code, so removing community controls alone does not reduce the final size.

| Build | Bytes | MiB |
|---|---:|---:|
| Unmodified pinned baseline | 56,851,071 | 54.217 |
| Embedded candidate | 57,041,821 | 54.399 |
| Change | +190,750 | +0.182 |

Final WASM SHA-256: `5f2ce769c11ae0343180009b8d0d30eb1c5f79c49342ba52fc9c3c416c01c825`.

The browser test exposed the pinned Save As dialog dispatching `file.save`, which reported `saveAs:false` for an unchanged suggested filename. The embedded wasm variant now dispatches `file.saveAs`; native/default behavior is unchanged. The repaired build was tested in the browser, **18 relevant Save As tests passed**, and the default web compile check was repeated successfully. WordCraft's Cmd+Shift+S opens Styles; use File > Save As for the bridge test.


## Files touched

- `ATTRIBUTION.md`
- `CHANGES.md`
- `apps/wordcraft-web/Cargo.toml`
- `apps/wordcraft-web/src/host.rs`
- `crates/engine/Cargo.toml`
- `crates/engine/src/sample.rs`
- `crates/formats/Cargo.toml`
- `crates/formats/src/latex/export.rs`
- `crates/mcp/Cargo.toml`
- `crates/mcp/src/server.rs`
- `crates/ui-egui/Cargo.toml`
- `crates/ui-egui/build.rs`
- `crates/ui-egui/src/app.rs`
- `crates/ui-egui/src/app/commands.rs`
- `crates/ui-egui/src/app/frame.rs`
- `crates/ui-egui/src/backstage.rs`
- `crates/ui-egui/src/canvas/input.rs`
- `crates/ui-egui/src/chrome.rs`
- `crates/ui-egui/src/credits.rs`
- `crates/ui-egui/src/dialogs/dispatch.rs`
- `crates/ui-egui/src/embedded.rs`
- `crates/ui-egui/src/file_dialogs.rs`
- `crates/ui-egui/src/icons.rs`
- `crates/ui-egui/src/keytips.rs`
- `crates/ui-egui/src/language_packs.rs`
- `crates/ui-egui/src/lib.rs`
- `crates/ui-egui/src/options.rs`
- `crates/ui-egui/src/ribbon.rs`
- `crates/ui-egui/src/ribbon/review.rs`
- `crates/ui-egui/src/theme.rs`
- `crates/ui-egui/src/widgets/buttons.rs`
- `crates/ui-egui/src/window_ui.rs`
- `embedded-test/artifact-search.json`
- `embedded-test/browser-results.json`
- `embedded-test/index.html`
- `embedded-test/sample.docx`
- `packaging/web/build-embedded.sh`

## Built-artifact string audit

Case-insensitive raw-byte searches over every generated `.wasm` and `.js`, including generated inline-helper modules. Every occurrence is recorded, including overlapping scheme/hostname searches. Offsets are zero-based. Binary context can span adjacent strings; a byte hit is not proof of a URL or of network activity.

| Needle | Remaining hits |
|---|---:|
| `discord` | 8 |
| `getartcraft` | 0 |
| `storytold` | 0 |
| `github.com` | 9 |
| `http://` | 346 |
| `https://` | 48 |

**Every remaining match, its file/byte offset, context and reason:** [artifact-search.json](embedded-test/artifact-search.json). The report also records every scanned file's SHA-256.

The eight `discord` substrings are English dictionary entries (`discordance` and `discordant` in four regional dictionaries); no Discord community URL remains.
Remaining URL text belongs to document/XML/SVG namespaces, dependency diagnostics and provenance, licence/source notices, shared translation catalog text, citation identifiers, link-editing placeholders, and the Brotli decompression dictionary (verified byte-for-byte against its crate source). These are retained data/metadata; the app's external navigation and startup URL-fetch entry points are disabled in this build.


## Local test page

Source checkout: `embedded-test/index.html` expects the generated app at `../dist/web/`. The delivered ZIP also includes a copy under `embedded-test/` whose iframe points to the ZIP's app root. Serve the extracted package on localhost, then open `/embedded-test/`. Only generated files and generic fixtures need to be served; do not expose the whole source checkout.
