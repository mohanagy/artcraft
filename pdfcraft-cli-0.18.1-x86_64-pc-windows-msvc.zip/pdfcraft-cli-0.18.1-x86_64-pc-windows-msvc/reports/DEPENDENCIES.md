# Dependency and build-time inventory

Conservative union of Cargo-resolved CLI production dependencies, build dependencies and proc macros for all three targets; dev-only dependency edges are excluded. Includes dependencies whose code may be removed by link-time dead-code elimination; not a claim that every crate is linked or its network/process APIs are reachable. Source matches also include inline test/example code; NOTES identifies enabled application paths.

## Declared licence families outside MIT / Apache-2.0 / BSD / ISC / OFL

Alternative licences are listed too; not every option applies simultaneously. Full expressions, sources, authors and target membership are in dependency-inventory.json.

- `BSL-1.0`: ryu 1.0.23, ryu-js 1.0.3
- `CC0-1.0`: dunce 1.0.5
- `LLVM-exception`: rustix 1.1.5
- `Unicode-3.0`: icu_collections 2.3.0, icu_locale_core 2.3.0, icu_normalizer 2.3.0, icu_normalizer_data 2.3.0, icu_properties 2.3.0, icu_properties_data 2.3.0, icu_provider 2.3.1, litemap 0.8.3, potential_utf 0.1.6, tinystr 0.8.4, unicode-ident 1.0.26, writeable 0.6.4, yoke 0.8.3, yoke-derive 0.8.4, zerofrom 0.1.8, zerofrom-derive 0.1.8, zerotrie 0.2.5, zerovec 0.11.8, zerovec-derive 0.11.6
- `Unlicense`: boa_ast 0.22.0, boa_engine 0.22.0, boa_gc 0.22.0, boa_interner 0.22.0, boa_macros 0.22.0, boa_parser 0.22.0, boa_string 0.22.0, byteorder-lite 0.1.0, memchr 2.8.3, small_btree 0.1.0, tag_ptr 0.1.0
- `Zlib`: bytemuck 1.25.2, bytemuck_derive 1.12.1, foldhash 0.2.0, lru-slab 0.1.3, miniz_oxide 0.8.9, miniz_oxide 0.9.1, tinyvec 1.13.3, zlib-rs 0.6.8, zune-core 0.5.3, zune-jpeg 0.5.15

## Source omissions and canonical declared-licence texts

- cms 0.2.3: canonical_Apache-2.0_text_for_declared_CMS_option; CMS source omits package licence files. Declaration: `Apache-2.0 OR MIT`.
- fmt-derive 0.1.2: canonical Apache-2.0 text for declared licence option; upstream fmt-derive source omits licence files. Declaration: `MIT OR Apache-2.0`.
- fmt-derive-proc 0.1.2: canonical Apache-2.0 text for declared licence option; upstream fmt-derive source omits licence files. Declaration: `MIT OR Apache-2.0`.
- rustls-cng 0.7.1: canonical Apache-2.0 text for explicitly declared licence option; upstream omits licence files. Declaration: `MIT/Apache-2.0`.

## Declared build scripts in the production/build graph

Cold builds execute build scripts/proc macros for the applicable target/host graph; cached Cargo artifacts can avoid rerunning them.

- anyhow 1.0.104: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/anyhow-1.0.104/build.rs`
- async-io 2.6.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/async-io-2.6.0/build.rs`
- aws-lc-rs 1.18.2: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/aws-lc-rs-1.18.2/build.rs`
- aws-lc-sys 0.46.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/aws-lc-sys-0.46.0/builder/main.rs`
- crc32fast 1.5.2: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc32fast-1.5.2/build.rs`
- crossbeam-deque 0.8.8: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crossbeam-deque-0.8.8/build.rs`
- crossbeam-epoch 0.9.21: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crossbeam-epoch-0.9.21/build.rs`
- crossbeam-utils 0.8.23: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crossbeam-utils-0.8.23/build.rs`
- curve25519-dalek 5.0.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/curve25519-dalek-5.0.0/build.rs`
- encoding_rs 0.8.42: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/encoding_rs-0.8.42/build.rs`
- flatbuffers 24.12.23: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/flatbuffers-24.12.23/build.rs`
- generic-array 0.14.7: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/generic-array-0.14.7/build.rs`
- getrandom 0.4.3: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/getrandom-0.4.3/build.rs`
- httparse 1.10.1: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/httparse-1.10.1/build.rs`
- icu_normalizer_data 2.3.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/icu_normalizer_data-2.3.0/build.rs`
- icu_properties_data 2.3.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/icu_properties_data-2.3.0/build.rs`
- libc 0.2.189: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libc-0.2.189/build.rs`
- libm 0.2.16: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libm-0.2.16/build.rs`
- memoffset 0.9.1: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/memoffset-0.9.1/build.rs`
- num-traits 0.2.19: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-traits-0.2.19/build.rs`
- parking_lot_core 0.9.12: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/parking_lot_core-0.9.12/build.rs`
- pdfcraft-cli 0.18.1: `/Users/mohammednaji/Desktop/projects/pdfcraft/apps/pdfcraft-cli/build.rs`
- pdfcraft-fonts 0.18.1: `/Users/mohammednaji/Desktop/projects/pdfcraft/crates/fonts/build.rs`
- portable-atomic 1.15.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/portable-atomic-1.15.0/build.rs`
- proc-macro-error 1.0.4: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/proc-macro-error-1.0.4/build.rs`
- proc-macro-error-attr 1.0.4: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/proc-macro-error-attr-1.0.4/build.rs`
- proc-macro2 1.0.107: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/proc-macro2-1.0.107/build.rs`
- quinn 0.11.12: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/quinn-0.11.12/build.rs`
- quinn-udp 0.5.16: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/quinn-udp-0.5.16/build.rs`
- quote 1.0.47: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/quote-1.0.47/build.rs`
- rayon-core 1.13.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rayon-core-1.13.0/build.rs`
- ring 0.17.14: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ring-0.17.14/build.rs`
- rustix 1.1.5: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustix-1.1.5/build.rs`
- rustls 0.23.46: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-0.23.46/build.rs`
- rustversion 1.0.23: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustversion-1.0.23/build/build.rs`
- serde 1.0.229: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde-1.0.229/build.rs`
- serde_core 1.0.229: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_core-1.0.229/build.rs`
- serde_json 1.0.154: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_json-1.0.154/build.rs`
- syn 1.0.109: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/syn-1.0.109/build.rs`
- thiserror 2.0.21: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/thiserror-2.0.21/build.rs`
- typeid 1.0.3: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/typeid-1.0.3/build.rs`
- winprint 0.2.1: `/Users/mohammednaji/.cargo/git/checkouts/winprint.rs-cff153194f434aaa/5f80b9b/build.rs`
- zerocopy 0.8.59: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zerocopy-0.8.59/build.rs`
- zmij 1.0.23: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/build.rs`

## Procedural macro entry points

Cold builds execute build scripts/proc macros for the applicable target/host graph; cached Cargo artifacts can avoid rerunning them.

- async-recursion 1.1.1: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/async-recursion-1.1.1/src/lib.rs`
- async-trait 0.1.92: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/async-trait-0.1.92/src/lib.rs`
- boa_macros 0.22.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/boa_macros-0.22.0/src/lib.rs`
- bytemuck_derive 1.12.1: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bytemuck_derive-1.12.1/src/lib.rs`
- curve25519-dalek-derive 0.1.1: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/curve25519-dalek-derive-0.1.1/src/lib.rs`
- der_derive 0.7.3: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/der_derive-0.7.3/src/lib.rs`
- displaydoc 0.2.7: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/displaydoc-0.2.7/src/lib.rs`
- dynify-macros 0.1.2: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/dynify-macros-0.1.2/src/lib.rs`
- enumflags2_derive 0.7.12: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enumflags2_derive-0.7.12/src/lib.rs`
- equator-macro 0.4.2: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/equator-macro-0.4.2/src/lib.rs`
- fmt-derive-proc 0.1.2: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/fmt-derive-proc-0.1.2/src/lib.rs`
- futures-macro 0.3.34: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-macro-0.3.34/src/lib.rs`
- multiversion_no_op 1.0.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/multiversion_no_op-1.0.0/src/lib.rs`
- num_enum_derive 0.7.6: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num_enum_derive-0.7.6/src/lib.rs`
- pastey 0.2.3: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pastey-0.2.3/src/lib.rs`
- phf_macros 0.13.1: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/phf_macros-0.13.1/src/lib.rs`
- phf_macros 0.14.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/phf_macros-0.14.0/src/lib.rs`
- pin-project-internal 1.1.13: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-internal-1.1.13/src/lib.rs`
- proc-macro-error-attr 1.0.4: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/proc-macro-error-attr-1.0.4/src/lib.rs`
- rustversion 1.0.23: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustversion-1.0.23/src/lib.rs`
- serde_derive 1.0.229: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_derive-1.0.229/src/lib.rs`
- serde_repr 0.1.21: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_repr-0.1.21/src/lib.rs`
- strum_macros 0.28.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum_macros-0.28.0/src/lib.rs`
- thiserror-impl 2.0.21: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/thiserror-impl-2.0.21/src/lib.rs`
- time-macros 0.2.32: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/time-macros-0.2.32/src/lib.rs`
- tls_codec_derive 0.4.2: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tls_codec_derive-0.4.2/src/lib.rs`
- tracing-attributes 0.1.31: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tracing-attributes-0.1.31/src/lib.rs`
- windows-implement 0.60.2: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/windows-implement-0.60.2/src/lib.rs`
- windows-interface 0.59.3: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/windows-interface-0.59.3/src/lib.rs`
- yoke-derive 0.8.4: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/yoke-derive-0.8.4/src/lib.rs`
- zbus_macros 5.19.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zbus_macros-5.19.0/src/lib.rs`
- zerocopy-derive 0.8.59: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zerocopy-derive-0.8.59/src/lib.rs`
- zerofrom-derive 0.1.8: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zerofrom-derive-0.1.8/src/lib.rs`
- zeroize_derive 1.5.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zeroize_derive-1.5.0/src/lib.rs`
- zerovec-derive 0.11.6: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zerovec-derive-0.11.6/src/lib.rs`
- zvariant_derive 5.15.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zvariant_derive-5.15.0/src/lib.rs`

## Conservative network/process API source matches

Matching APIs can be in inline tests/examples or code removed at link time. This is not a reachability claim. File/line/snippet evidence is in dependency-inventory.json; NOTES.md identifies enabled/disabled application paths.

- anyhow 1.0.104: 2 matches
- async-io 2.6.0: 19 matches
- async-process 2.5.0: 3 matches
- autocfg 1.5.1: 5 matches
- aws-lc-sys 0.46.0: 1 matches
- boa_gc 0.22.0: 2 matches
- cc 1.5.1: 16 matches
- cmake 0.1.58: 7 matches
- craft-print 0.1.0: 5 matches
- crc32fast 1.5.2: 1 matches
- find-msvc-tools 0.1.14: 3 matches
- httparse 1.10.1: 1 matches
- hyper-rustls 0.27.10: 2 matches
- hyper-util 0.1.21: 29 matches
- libc 0.2.189: 5 matches
- mio 1.2.4: 138 matches
- pdfcraft-cli 0.18.1: 2 matches
- pdfcraft-engine 0.18.1: 1 matches
- pdfcraft-export 0.18.1: 1 matches
- pdfcraft-platform 0.18.1: 1 matches
- pdfcraft-print 0.18.1: 4 matches
- pkg-config 0.3.34: 2 matches
- portable-atomic 1.15.0: 2 matches
- proc-macro-crate 3.5.0: 1 matches
- proc-macro2 1.0.107: 2 matches
- quinn 0.11.12: 24 matches
- quinn-udp 0.5.16: 11 matches
- quote 1.0.47: 1 matches
- reqwest 0.13.5: 18 matches
- ring 0.17.14: 2 matches
- rustc_version 0.4.1: 2 matches
- rustix 1.1.5: 2 matches
- rustls 0.23.46: 4 matches
- rustversion 1.0.23: 2 matches
- security-framework 3.7.0: 45 matches
- serde 1.0.229: 1 matches
- serde_core 1.0.229: 1 matches
- sigstore-rekor 0.6.6: 3 matches
- sigstore-tsa 0.6.6: 2 matches
- socket2 0.6.5: 7 matches
- syn 1.0.109: 1 matches
- thiserror 2.0.21: 2 matches
- tokio 1.53.1: 129 matches
- tokio-util 0.7.20: 7 matches
- typeid 1.0.3: 1 matches
- version_check 0.9.5: 1 matches
- windows-implement 0.60.2: 1 matches
- winprint 0.2.1: 6 matches
- winresource 0.1.34: 4 matches
- zbus 5.19.0: 33 matches
- zerocopy 0.8.59: 1 matches
- zmij 1.0.23: 1 matches
