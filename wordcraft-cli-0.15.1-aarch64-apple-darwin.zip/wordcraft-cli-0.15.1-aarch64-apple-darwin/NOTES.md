# wordcraft-cli 0.15.1 — offline release notes

Date: 2026-11-08. Local `embed/cli`; no push, publication or upload.

Original base: `08afab50b6a1ed19f9af55bb9f74d18f5e17bfa0`. CLI branch started from embedded-build commit `93862df761f235a292d33afb756f83b3c36e8f94`, not main. The final source commit/tree and source-input fingerprint are recorded in `SOURCE.json` supplied with the archives. Rust/Cargo source inputs are checked against the exact build snapshot; reports were written afterward.

## Binaries and versions

| Target | Binary bytes | Version output | SHA-256 |
|---|---:|---|---|
| `aarch64-apple-darwin` | 81,634,816 | `wordcraft-cli 0.15.1` | `122cd743a53bac062c2bb79137a91a284b0240d30a5bf53136616a8fce44b2d8` |
| `x86_64-apple-darwin` | 83,725,600 | `wordcraft-cli 0.15.1` | `65fc554b731e38db73d088bb5d25fc898bd54248e0537f7bd692237e09aa93f9` |
| `x86_64-pc-windows-msvc` | 88,073,728 | Not executed; Cargo package version 0.15.1 | `c6dd3d10381df21c9723d7578621eff07b95ff242cba1c24b6b16c4e19488c35` |

Windows is cross-compiled, PE/import-inspected and built with static MSVC C runtime. Import inspection found no VCRUNTIME/MSVCP/UCRT runtime DLL dependency. Windows OS DLL imports remain; see `reports/binary-inspection.json`. Windows execution, version output, confinement behavior and performance are **NOT VERIFIED** here. Both macOS binaries were executed; Intel ran through Rosetta 2 on Apple Silicon, not physical Intel hardware. They import only macOS system libraries/frameworks. Cargo strips symbols; inspection found no DWARF/.debug sections. No PDB is packaged.

## Exact build setup

Rust 1.99.1 via rustup; LLVM/LLD 23.1.5; cargo-xwin 0.23.1; Microsoft SDK cache 10.0.26100. Targets: aarch64-apple-darwin, x86_64-apple-darwin, x86_64-pc-windows-msvc. These are MSVC builds, not GNU substitutes.

From the repository root, the release environment was:

```sh
export PATH=/opt/homebrew/opt/lld/bin:/opt/homebrew/opt/llvm/bin:/Users/mohammednaji/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin
export CARGO_BUILD_JOBS=2
export CARGO_PROFILE_RELEASE_OPT_LEVEL=3
export CARGO_PROFILE_RELEASE_LTO=thin
export CARGO_PROFILE_RELEASE_STRIP=symbols
export CARGO_TARGET_X86_64_PC_WINDOWS_MSVC_RUSTFLAGS='-C target-feature=+crt-static -C debuginfo=0'
export XWIN_ARCH=x86_64
export CRAFT_FONTS_DIR=/Users/mohammednaji/Desktop/projects/craft-build-inputs/fonts
export CRAFT_I18N_DIR=/Users/mohammednaji/Desktop/projects/craft-build-inputs/wordcraft-embedded-i18n
export CRAFT_I18N_REQUIRED=1
cargo build --release --locked --target aarch64-apple-darwin -p wordcraft-cli --features offline
cargo build --release --locked --target x86_64-apple-darwin -p wordcraft-cli --features offline
cargo xwin build --release --locked --target x86_64-pc-windows-msvc -p wordcraft-cli --features offline
```

Release panic/unwind behavior is retained; panic=abort was not enabled. All builds used --locked. Tool-generated compiler/linker defaults remain those of the versions above. Optional Microsoft CRT debug PDBs were not downloaded; the linker emitted missing-PDB warnings while successfully producing stripped release executables. Exact logs and commands are in `reports/logs` and `reports/build-runs.json`.

## Profile and network/process behavior

`offline` is opt-in and is the feature used for these archives. Feature-off defaults retain the original behavior. MCP starts only through the `mcp` command, uses stdin/stdout, replies before EOF, and exits when stdin closes. It is not registered with another application and never starts a listener automatically. No telemetry/update check or model/data download is started by the tested startup/open/edit/save/convert workflows.

Zotero CLI dispatch and desktop `mcp --connect` bridging are disabled in this profile. The language-pack font-store backend is not initialized, so `proof.installPack` and network refresh have no download backend even if an existing user consent setting was on. MCP promotional website/community metadata, the built-in sample hyperlink and the LaTeX attribution URL are omitted. Existing installed/bundled proofing resources remain available.

Four listed MCP tools (screenshot, click, key, ui_inspect) require a desktop backend and are unavailable in standalone offline mode; they return the existing needs-app error. They do not establish a connection. The tool listing records that limitation. Native read-aloud uses local OS processes/services (for example defaults/say on macOS, platform voice programs elsewhere); it is opt-in and was not exercised.

The offline profile removes the application network integrations listed above; it is not an OS firewall. Optional OS services such as printing/speech, and explicitly mounted remote filesystems, are controlled by the OS and can involve external devices/services. Leave those opt-in commands unused for the strict offline workflow verified here. Runtime checks used an OS sandbox denying network access; no print/speech/model-download operation was part of those checks. `reports/DEPENDENCIES.md` lists network/process-capable source matches, build scripts and proc macros, with full source evidence in dependency-inventory.json. A dependency API match is not proof it is linked or reachable.

## Folder restrictions and end-to-end results

`--automation-read-root` and `--automation-write-root` apply to the headless MCP server. Relative Word paths resolve against its working directory; use absolute paths or start it in the read root. Existing symlinks and parent components are resolved before checking whole path components. A missing read/write capability refuses that access; with neither flag, offline MCP grants neither. A save back to a read-only input folder is refused unless that location is also inside the write root. Standalone explicit-file commands such as convert/info/run keep their existing CLI semantics and do not accept these MCP-only flags.

Verified on the final Apple Silicon binary: open the original generic DOCX (paragraphs, a table and our own solid-color picture), replace its first paragraph, add a review comment, save to DOCX, then inspect the saved XML/image/comment parts. Read and write paths inside their roots work. Relative escape, bare .., absolute outside path and outward symlink reads/writes were refused with explicit root/authority errors. A nested insert.picture read outside the root was also refused; the outside picture existed, avoiding a missing-file false positive. No forbidden output appeared. Missing-read, missing-write and no-root cases were refused.

Roots protect application file operations, not against an independent process racing to change the filesystem after validation. They are not an OS-wide filesystem sandbox. Filesystem and workflow acceptance ran on Apple Silicon; Intel was exercised for version/startup/conversion through Rosetta; Windows runtime checks remain unverified.

The exact commands, JSON requests/responses, sandbox profile, working directories and output assertions are in `reports/runtime-checks.json`. Only original generic fixtures were used; the Microsoft licence attachment was a legal document, not an application fixture.

## Timing and memory

Warm filesystem cache; fresh process per run. Five --version launch/exit samples, three interactive stdio MCP initialize-ready/EOF samples, three 30-page conversion samples. RSS is macOS /usr/bin/time -l maximum resident set size, bytes. Other machine workload was not controlled. Intel results include Rosetta 2 and are not physical-Intel performance results.

The benchmark input is 30 A4 pages, 11,280 original words, 12 body paragraphs/page plus headings, with explicit page breaks and Source Sans 3. This is a simple text workload, not an OCR, table/picture stress, cold-start or document-fidelity benchmark. Separate small fixtures cover the requested table/picture/form workflows. Word converts DOCX to PDF; PDF exports that PDF to DOCX. Inputs were confirmed at 30 pages; converted DOCX output includes the page-30 heading.

| Target | --version launch/exit median ms | MCP initialize-ready median ms | 30-page conversion median s | Conversion peak RSS MiB |
|---|---:|---:|---:|---:|
| `aarch64-apple-darwin` | 5.64 | 5.52 | 0.0557 | 37.41 |
| `x86_64-apple-darwin` | 37.99 | 36.50 | 0.1124 | 32.93 |
| `x86_64-pc-windows-msvc` | Not run | Not run | Not run | Not run |

Full samples, commands, host version, input hashes and raw time output are in reports/performance.json.

## Checks and string audit

- offline-tests: PASS — `cargo test --locked -p wordcraft-cli -p wordcraft-mcp --features wordcraft-cli/offline`.
- offline-link-tests: PASS — `cargo test --locked -p wordcraft-engine -p wordcraft-formats --lib --features wordcraft-engine/offline offline_tests`.
- clippy: PASS — `cargo clippy --locked -p wordcraft-cli -p wordcraft-mcp -p wordcraft-engine -p wordcraft-formats --all-targets --features wordcraft-cli/offline -- -D warnings`.
- ci: PASS — `cargo xtask ci`.
- All nine repository CI stages passed. The default bridge author-error precedence is explicitly regression-tested; its check is gated to offline mode.

Every occurrence of discord, getartcraft, storytold, http:// and https:// was scanned in ASCII/UTF-8, UTF-16LE and UTF-16BE. Offsets, contexts and per-hit reasons are in reports/artifact-search.json; zero unclassified hits. No byte-scrubbing of required format data was performed.

| Target | discord | getartcraft | storytold | http:// | https:// |
|---|---:|---:|---:|---:|---:|
| `aarch64-apple-darwin` | 8 | 0 | 0 | 476 | 103 |
| `x86_64-apple-darwin` | 8 | 0 | 0 | 464 | 104 |
| `x86_64-pc-windows-msvc` | 8 | 0 | 0 | 471 | 104 |

Discord matches are ordinary discordance/discordant proofing words. Remaining scheme/URL matches are individually explained namespace/format tokens, licensed font metadata, proofing/Brotli data, dependency references, document-link edit/recognition descriptions or architecture-specific code immediates. None is presented as a promotional navigation action by the offline CLI. Input documents may retain their own links as data; the CLI does not follow them.

## Licences, inventory and delivery

Program MIT/Apache licence and notice files are included unchanged. THIRD-PARTY-LICENSES.txt and reports/dependency-inventory.json cover the conservative production/build dependency graph across targets; dev-only edges are excluded. All identified packages have corresponding licence texts in this generated bundle. Where CMS, fmt-derive/fmt-derive-proc or rustls-cng omit licence files in their original source, the bundle explicitly records the declared Apache-2.0 option and the provenance of the canonical text; it does not label that text as a package-specific upstream file. Declared alternative licences and non-core families (including Unicode-3.0, Zlib, Unlicense, CC0-1.0, BSL-1.0, LLVM exception and, where resolved, CDLA-Permissive-2.0) are called out per package in reports/DEPENDENCIES.md. Font OFL/other notices and the Rust standard-library copyright notice are retained. Windows archives also include the approved Microsoft build-tools terms and source attribution; Microsoft runtime and OS terms are outside the listed open-source families. macOS system frameworks are provided by the OS, not copied into the archive.

Full top-level CLI commands/options: reports/CLI-HELP.txt. Full engine command listing: reports/ENGINE-COMMANDS.json. Full MCP tool list (17 tools), one-line descriptions and standalone limitations: reports/MCP-TOOLS.md and MCP-TOOLS.json. Full cold-build build.rs/proc-macro inventory: reports/DEPENDENCIES.md.

One ZIP per target: `wordcraft-cli-0.15.1-<target>.zip`, each with the executable, licences, this NOTES.md and reports. SHA256SUMS covers the six delivered ZIPs. `patches-wordcraft-cli/` contains the ordered git format-patch series against the original base, including the embedded-profile history from which this branch started. Patch application and archive byte checks are recorded in the delivery manifest.

Known limits: no Windows execution/performance acceptance; Intel tested via Rosetta only; no exhaustive document-fidelity or every-command acceptance; OCR/optional OS services not exercised; standalone explicit-file CLI operations retain their original filesystem option scopes. No source behavior was changed beyond this opt-in offline profile, its capability defaults and the documented exclusions.

## Files changed in the CLI task

- `NOTES.md`
- `apps/wordcraft-cli/Cargo.toml`
- `apps/wordcraft-cli/src/main.rs`
- `apps/wordcraft-cli/src/tests.rs`
- `apps/wordcraft-cli/tests/it/help.rs`
- `crates/engine/Cargo.toml`
- `crates/engine/src/file_access.rs`
- `crates/engine/src/sample.rs`
- `crates/formats/Cargo.toml`
- `crates/formats/src/latex/export.rs`
- `crates/mcp/Cargo.toml`
- `crates/mcp/src/server.rs`
