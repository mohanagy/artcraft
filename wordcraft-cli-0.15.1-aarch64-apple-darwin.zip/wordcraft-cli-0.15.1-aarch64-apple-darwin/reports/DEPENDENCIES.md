# Dependency and build-time inventory

Conservative union of Cargo-resolved CLI production dependencies, build dependencies and proc macros for all three targets; dev-only dependency edges are excluded. Includes dependencies whose code may be removed by link-time dead-code elimination; not a claim that every crate is linked or its network/process APIs are reachable. Source matches also include inline test/example code; NOTES identifies enabled application paths.

## Declared licence families outside MIT / Apache-2.0 / BSD / ISC / OFL

Alternative licences are listed too; not every option applies simultaneously. Full expressions, sources, authors and target membership are in dependency-inventory.json.

- `BSL-1.0`: ryu 1.0.23
- `CC0-1.0`: dunce 1.0.5
- `CDLA-Permissive-2.0`: webpki-roots 1.0.11
- `LLVM-exception`: rustix 1.1.5
- `Unicode-3.0`: unicode-ident 1.0.26, unicode-normalization 0.1.26, yoke 0.8.4, yoke-derive 0.8.4, zerofrom 0.1.8, zerofrom-derive 0.1.8
- `Unlicense`: aho-corasick 1.1.5, byteorder-lite 0.1.0, memchr 2.8.3
- `Zlib`: bytemuck 1.25.2, bytemuck_derive 1.12.1, dispatch2 0.3.1, foldhash 0.2.0, miniz_oxide 0.8.9, miniz_oxide 0.9.1, objc2-core-foundation 0.3.2, objc2-core-text 0.3.2, tinyvec 1.13.3, zlib-rs 0.6.8, zune-core 0.5.3, zune-jpeg 0.5.15

## Source omissions and canonical declared-licence texts


## Declared build scripts in the production/build graph

Cold builds execute build scripts/proc macros for the applicable target/host graph; cached Cargo artifacts can avoid rerunning them.

- aws-lc-rs 1.18.2: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/aws-lc-rs-1.18.2/build.rs`
- aws-lc-sys 0.46.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/aws-lc-sys-0.46.0/builder/main.rs`
- craft-proof 0.1.0: `/Users/mohammednaji/.cargo/git/checkouts/craft-libs-d830b991a08c6c3d/01315d9/crates/proof/build.rs`
- crc32fast 1.5.2: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc32fast-1.5.2/build.rs`
- crossbeam-deque 0.8.8: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crossbeam-deque-0.8.8/build.rs`
- crossbeam-epoch 0.9.21: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crossbeam-epoch-0.9.21/build.rs`
- crossbeam-utils 0.8.23: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crossbeam-utils-0.8.23/build.rs`
- encoding_rs 0.8.42: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/encoding_rs-0.8.42/build.rs`
- generic-array 0.14.7: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/generic-array-0.14.7/build.rs`
- getrandom 0.3.4: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/getrandom-0.3.4/build.rs`
- getrandom 0.4.3: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/getrandom-0.4.3/build.rs`
- httparse 1.10.1: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/httparse-1.10.1/build.rs`
- libc 0.2.191: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libc-0.2.191/build.rs`
- libm 0.2.16: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libm-0.2.16/build.rs`
- num-traits 0.2.19: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-traits-0.2.19/build.rs`
- objc2 0.6.5: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/objc2-0.6.5/build.rs`
- proc-macro2 1.0.107: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/proc-macro2-1.0.107/build.rs`
- quote 1.0.47: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/quote-1.0.47/build.rs`
- rayon-core 1.13.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rayon-core-1.13.0/build.rs`
- ring 0.17.14: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ring-0.17.14/build.rs`
- rustix 1.1.5: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustix-1.1.5/build.rs`
- rustls 0.23.46: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-0.23.46/build.rs`
- rustversion 1.0.23: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustversion-1.0.23/build/build.rs`
- serde 1.0.229: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde-1.0.229/build.rs`
- serde_core 1.0.229: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_core-1.0.229/build.rs`
- serde_json 1.0.154: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_json-1.0.154/build.rs`
- thiserror 2.0.21: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/thiserror-2.0.21/build.rs`
- wordcraft-fonts 0.15.1: `/Users/mohammednaji/Desktop/projects/wordcraft/crates/fonts/build.rs`
- zerocopy 0.8.61: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zerocopy-0.8.61/build.rs`
- zmij 1.0.23: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/build.rs`

## Procedural macro entry points

Cold builds execute build scripts/proc macros for the applicable target/host graph; cached Cargo artifacts can avoid rerunning them.

- bytemuck_derive 1.12.1: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bytemuck_derive-1.12.1/src/lib.rs`
- multiversion_no_op 1.0.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/multiversion_no_op-1.0.0/src/lib.rs`
- rustversion 1.0.23: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustversion-1.0.23/src/lib.rs`
- serde_derive 1.0.229: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_derive-1.0.229/src/lib.rs`
- thiserror-impl 2.0.21: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/thiserror-impl-2.0.21/src/lib.rs`
- windows-implement 0.60.2: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/windows-implement-0.60.2/src/lib.rs`
- windows-interface 0.59.3: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/windows-interface-0.59.3/src/lib.rs`
- yoke-derive 0.8.4: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/yoke-derive-0.8.4/src/lib.rs`
- zerocopy-derive 0.8.61: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zerocopy-derive-0.8.61/src/lib.rs`
- zerofrom-derive 0.1.8: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zerofrom-derive-0.1.8/src/lib.rs`
- zeroize_derive 1.5.0: `/Users/mohammednaji/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zeroize_derive-1.5.0/src/lib.rs`

## Conservative network/process API source matches

Matching APIs can be in inline tests/examples or code removed at link time. This is not a reachability claim. File/line/snippet evidence is in dependency-inventory.json; NOTES.md identifies enabled/disabled application paths.

- autocfg 1.5.1: 5 matches
- aws-lc-sys 0.46.0: 1 matches
- cc 1.6.0: 16 matches
- cmake 0.1.58: 7 matches
- craft-atomic 0.1.0: 3 matches
- craft-font-store 0.1.0: 13 matches
- crc32fast 1.5.2: 1 matches
- find-msvc-tools 0.1.14: 3 matches
- getrandom 0.3.4: 2 matches
- httparse 1.10.1: 1 matches
- libc 0.2.191: 5 matches
- objc2 0.6.5: 1 matches
- pkg-config 0.3.34: 2 matches
- proc-macro2 1.0.107: 2 matches
- quote 1.0.47: 1 matches
- ring 0.17.14: 2 matches
- rustix 1.1.5: 2 matches
- rustls 0.23.46: 4 matches
- rustversion 1.0.23: 2 matches
- security-framework 3.7.0: 45 matches
- serde 1.0.229: 1 matches
- serde_core 1.0.229: 1 matches
- thiserror 2.0.21: 2 matches
- ureq 3.5.0: 28 matches
- version_check 0.9.5: 1 matches
- windows-implement 0.60.2: 1 matches
- wordcraft-engine 0.15.1: 9 matches
- wordcraft-mcp 0.15.1: 6 matches
- wordcraft-zotero 0.15.1: 9 matches
- zerocopy 0.8.61: 1 matches
- zmij 1.0.23: 1 matches
